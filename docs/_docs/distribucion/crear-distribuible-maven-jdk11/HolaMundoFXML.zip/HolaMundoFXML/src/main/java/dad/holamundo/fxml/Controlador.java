package dad.holamundo.fxml;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;

public class Controlador implements Initializable {
	
	// modelo
	
	private Modelo model = new Modelo();
	
	// vista
	
	@FXML
	private VBox view;
	
	@FXML
	private TextField nombreText;
	
	@FXML
	private Button saludarButton;
	
	@FXML
	private Label saludoLabel;
	
	// constructor
	
	public Controlador() throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Vista.fxml"));
		loader.setController(this);
		loader.load();
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {

		// bindeos
		
		model.nombreProperty().bind(nombreText.textProperty());
		
		saludoLabel.textProperty().bind(model.saludoProperty());
		
		saludarButton.disableProperty().bind(model.nombreProperty().isEmpty());
	
	}
	
	@FXML
	private void onSaludarButtonAction(ActionEvent e) {
		if (!model.getNombre().isEmpty())
			model.setSaludo("�Hola " + model.getNombre() + "!");
		else
			model.setSaludo("");
	}

	public Modelo getModel() {
		return model;
	}
	
	public VBox getView() {
		return view;
	}

}
